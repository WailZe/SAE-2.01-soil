import java.util.*;
import java.lang.String;
/**
 * Décrivez votre classe Entrepôt ici.
 *
 * @author anselot steven
 * @version (un numéro de version ou une date)
 */
public class Entrepôt extends Coordonnee
{
    // variables d'instance - remplacez l'exemple qui suit par le vôtre
    private int numEntrepot;
    private String natureStock;
    private int stock;
    /**
     * Constructeur d'objets de classe Entrepôt
     */
    public Entrepôt()
    {
        // initialisation des variables d'instance
        numEntrepot = 0;
        natureStock = "nickel";
        stock = 0;
    }
    
    public Entrepôt(int ne, String ns, int s)
    {
        numEntrepot = ne;
        natureStock = ns;
        stock = s;
    }

    public int getNumEnt()
    {
        return numEntrepot;
    }
    
    public String getNatureE()
    {
        return natureStock;
    }
    
    public int getStock()
    {
        return stock;
    }
}
