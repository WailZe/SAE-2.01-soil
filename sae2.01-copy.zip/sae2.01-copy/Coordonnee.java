
/**
 * Décrivez votre classe Coordonnee ici.
 *
 * @author anselot steven
 * @version (un numéro de version ou une date)
 */
public class Coordonnee
{
    // variables d'instance - remplacez l'exemple qui suit par le vôtre
    private int x;
    private int y;

    /**
     * Constructeur d'objets de classe Coordonnee
     */
    public Coordonnee()
    {
        // initialisation des variables d'instance
        x = 0;
        y = 0;
    }
    
    public Coordonnee(int vx, int vy)
    {
        x = vx;
        y = vy;
    }
    
    public int getPosition()
    {
        return x + y;
    }
}
